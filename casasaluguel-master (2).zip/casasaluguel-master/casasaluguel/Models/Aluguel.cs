﻿namespace casaalguelmvc.Models
{
    public class Aluguel
    {
        public int Id { get; set; }
        public string Moradores { get; set; }
        public string Casa { get; set; }
        public DateTime Data { get; set; }
    }
}
