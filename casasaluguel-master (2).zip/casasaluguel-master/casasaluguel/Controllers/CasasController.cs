﻿using Microsoft.AspNetCore.Mvc;

namespace SeuProjeto.Controllers
{
    public class CasasController : Controller
    {
        // Simulação de uma lista de carros
        public IActionResult Index()
        {
            var casas = new List<string>
            {
                "Casa grande",
                "Casa média",
                "Casa pequena"
            };

            // Passando a lista de carros para a View
            return View(casas);
        }
    }
}
