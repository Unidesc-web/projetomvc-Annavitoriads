﻿namespace SeuProjeto.Models
{
    public class CasasBase
    {
        private string endereco;
    }
}