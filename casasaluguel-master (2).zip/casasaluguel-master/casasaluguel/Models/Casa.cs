﻿using System;

namespace SeuProjeto.Models
{
    public class Casa
    {
        public int Id { get; set; }
        public string Tamanho { get; set; }
        public string Espaço { get; set; }
        public int Varanda { get; set; }
        public bool Disponivel { get; set; }
    }
}
