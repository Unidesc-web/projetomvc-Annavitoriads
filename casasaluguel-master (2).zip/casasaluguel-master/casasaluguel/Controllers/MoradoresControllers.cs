﻿using Microsoft.AspNetCore.Mvc;

namespace SeuProjeto.Controllers
{
    public class MoradoresController : Controller
    {
        
        public IActionResult Index()
        {
            var clientes = new List<string>
            {
                "Anna Vitoria",
                "João Pedro",
                "Maria Luisa"
            };

            
            return View(clientes);
        }
    }
}
