﻿using Microsoft.AspNetCore.Mvc;

namespace SeuProjeto.Controllers
{
    public class AluguelCasasController : Controller
    {
       
        public IActionResult Index()
        {
            var aluguel = new List<string>
            {
                "Anna Vitoria alugou a Casa grande",
                "João Pedro alugou a Casa média",
                "Maria Luisa alugou a Casa pequena"
            };

            
            return View(aluguel);
        }
    }
}
